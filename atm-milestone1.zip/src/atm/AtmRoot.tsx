import React from "react";
import { Composition } from "remotion";
import { ATMEpisode01 } from "./compositions/ATMEpisode01";
import { FPS, HEIGHT, TOTAL_FRAMES, WIDTH } from "./config/timing";

export const AtmRoot: React.FC = () => (
  <Composition
    id="ATMEpisode01"
    component={ATMEpisode01}
    durationInFrames={TOTAL_FRAMES}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
    defaultProps={{ debugHud: true }}
  />
);
