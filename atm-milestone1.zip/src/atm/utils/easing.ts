// Fungsi murni: input 0..1, output 0..1. Tanpa state.
export const clamp01 = (x: number) => Math.min(1, Math.max(0, x));

export const easeInOutCubic = (x: number) => {
  const t = clamp01(x);
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
};

export const easeOutCubic = (x: number) => 1 - Math.pow(1 - clamp01(x), 3);

// Ease-out dengan overshoot kecil (default 0.4 → sekitar 2-3% melewati target).
export const easeOutBack = (x: number, overshoot = 0.4) => {
  const t = clamp01(x);
  const c3 = overshoot + 1;
  return 1 + c3 * Math.pow(t - 1, 3) + overshoot * Math.pow(t - 1, 2);
};

// Progres 0..1 dari frame, untuk jendela [from, from+duration].
export const progress = (frame: number, from: number, duration: number) =>
  clamp01((frame - from) / Math.max(1, duration));
